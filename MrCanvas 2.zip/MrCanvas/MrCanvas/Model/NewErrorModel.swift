//
//  NewErrorModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/05/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation

struct NewErrorModel : Codable {
  let successBool: Bool?
  let successCode: String?
  let response: [String]?
  let responseType: String?
  let errorObj: ErrorObj?

  
  enum CodingKeys: String, CodingKey {
    
    case successBool = "successBool"
    case successCode = "successCode"
    case response = "response"
    case responseType = "responseType"
    case errorObj = "ErrorObj"
  }
  
  init(from decoder: Decoder) throws {
    let values = try decoder.container(keyedBy: CodingKeys.self)
    successBool = try values.decodeIfPresent(Bool.self, forKey: .successBool)
    successCode = try values.decodeIfPresent(String.self, forKey: .successCode)
    response = try values.decodeIfPresent([String].self, forKey: .response)
    responseType = try values.decodeIfPresent(String.self, forKey: .responseType)
    errorObj = try values.decodeIfPresent(ErrorObj.self, forKey: .errorObj)
  }
  
}

