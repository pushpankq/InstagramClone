//
//  LoginModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import SwiftyJSON
/// use one time one case
///
/// - SignUp: If User is signing up
/// - Login: If user is signing in
enum OperationType :String{
    case SignUp
    case Login
}


/// SyncAccountModel Class
class SyncAccountModel {
    
    // Completion Handler
    typealias loginData = (Bool) -> Void
    typealias userProfileData = (Bool) -> Void
    
    
    lazy var alertMessage: String = ""
    lazy var email: String = ""
    lazy var password: String = ""
    lazy var successBool = false
    lazy var requestData = [String:Any]()
    
    
    init(email: String, password: String) {
        
        self.email = email
        self.password = password
        self.alertMessage = ""
    }
}

// MARK: - SyncAccountModel Validation
/// Login form Validation
///
/// - Returns: form is valid or not
extension SyncAccountModel {

    func loginFormValidate() -> Bool {
        
        if email.isEmpty || password.isEmpty ||  !isValidEmail( emailString: email) {
            
            alertMessage = Constants.Validation.emailOrPasswordErrorMessage
            return false
        }
        return true
    }
    
}
    
// MARK: - User Login/ Sign Up
/// Accessing data from Login web api
///
/// - Parameter completionHandler: using callback to send data in controller
   extension SyncAccountModel {

    func userLogin(_ operationType: String, completionHandler: @escaping loginData)  {
        
        var loginOrSignUpURL = ""
        
        if operationType == OperationType.Login.rawValue {
            loginOrSignUpURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.loginUser
        }
        else if operationType == OperationType.SignUp.rawValue {
            loginOrSignUpURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.createUser
        }
        
        let dataDictionary = createRequestData(operationType)
        
        APIManager.shared.postService(loginOrSignUpURL, andParameter: dataDictionary) { [unowned self] (data, error) in
            
            if error != nil  {
                self.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            }  else {
                do {
                  
                  let json = try JSON(data: data!)
                  print(json)

//                    let loginModelData = try JSONDecoder().decode(LoginModel.self, from: data!)
//                    let isSuccess = loginModelData.successBool
//                    if isSuccess! {
//
//                      let userId = (loginModelData.response?.loginData?.id)!
//                      Helper.saveUserDefault(key: "userToken", value: (loginModelData.response?.loginData?.token)!)
//                      Helper.saveUserDefault(key: "userId", value: String(userId))
//                      Helper.saveUserDefault(key: "emailId", value: self.email)
//
//
//
//
////                        let userId = (loginData.response?.user_id)!
//
////                        Helper.saveUserDefault(key: "userToken", value: (loginData.response?.userToken)!)
//                        Helper.saveUserDefault(key: "installed", value: "Yes")
//
//                        self.getProfile(userID: userId, completionHandler: { (isSuccess) in
//
//                            if isSuccess {
//                                completionHandler(true)
//                            } else {
//                                completionHandler(false)
//                            }
//                        })
//                    }
                  
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
        }
    }
}

// MARK: - Get User Profile
/// Accessing data from User SignUp web api
///
/// - Parameter completionHandler: using callback to send data in controller
extension SyncAccountModel {

    func getProfile(userID: Int , completionHandler: @escaping userProfileData) {
        
        let getProfileURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.getProfle
        var requestData = [String:Any]()
        
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kDeviceType] = Constants.ApiKeysValues.iOS
        requestData[Constants.ApiKeys.kUserid] = userID
        
        var registerDataDict = [String: Any]()
        registerDataDict[Constants.ApiKeys.kRequestData] = requestData
        
        APIManager.shared.postService(getProfileURL, andParameter: registerDataDict) {[weak self] (data, error) in
            
            if error != nil  {
                self!.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
            } else {
                
                do {
                    let _ = try JSONDecoder().decode(ProfileModel.self, from: data!)
                    completionHandler(true)
                    
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        self?.alertMessage = (loginError.errorObj?.errorMsg)!
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self?.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
            
        }
        
    }
    
    
    /// Creating request body for accessing the web api
    ///
    /// - Parameter isLogin: if isLogin is true, we are using the request body for user login api otherwise for user SignUp api
    /// - Returns: Request body
    func createRequestData(_ operationType: String) -> [String:Any] {
      
            
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kDeviceType] = Constants.ApiKeysValues.iOS
        requestData[Constants.ApiKeys.kDeviceID] = "fdgf"
        requestData[Constants.ApiKeys.kDeviceToken] = "fdgf"
        requestData[Constants.ApiKeys.kEmail] = email
        requestData[Constants.ApiKeys.kPassword] = password
        
        if operationType == OperationType.SignUp.rawValue {
            requestData[Constants.ApiKeys.kUsername] = email
        }
        
        var dataDictionary = [String: Any]()
        dataDictionary[Constants.ApiKeys.kRequestData] = requestData
        return dataDictionary
    }
    
}

