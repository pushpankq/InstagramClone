//
//  SideMenuModel.swift
//  MrCanvas
//
//  Created by Mayank Singh on 22/04/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import UIKit


/// side bar data objects

struct SideMenuDataModel  {
    
    let headerTitle: String?
    let sideMenuItems: [String]?
    let hederTitleImage: UIImage?
}

//struct SideMenuDataModelList {
//
//
//}



/// side Menu Model class
class SideMenuModel {
    
    lazy var alertMessage: String = ""
    typealias loginData = (Bool) -> Void
    
    init() {
        // do nothing here...
    }
}



// MARK: - side Menu Model class extension
// getting response from uer logout api
extension SideMenuModel {
    
    func userSignOut( completionHandler: @escaping loginData)  {
        
        guard let token = Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) else { return }
        guard let userID = Helper.getUserDefault(key: "userId") else { return }
        
        var requestData = [String:Any]()
        requestData[Constants.ApiKeys.kVCode] = Constants.ApiKeysValues.vCode
        requestData[Constants.ApiKeys.kApiKey] = Constants.ApiKeysValues.apiKey
        requestData[Constants.ApiKeys.kToken] = token
        requestData[Constants.ApiKeys.kUserid] = userID
        
        var dataDictionary = [String: Any]()
        dataDictionary[Constants.ApiKeys.kRequestData] = requestData
        
        let  logoutURL = Constants.ApiEndPoint.baseURL + Constants.ApiEndPoint.logout
        
        APIManager.shared.postService(logoutURL, andParameter: dataDictionary) { (data, error) in
            
            if error != nil  {
                
                self.alertMessage = (error?.localizedDescription)!
                completionHandler(false)
                
            } else {
                
                do {
                    _ = try JSONDecoder().decode(LogoutModel.self, from: data!)
                    completionHandler(true)
                    
                } catch  _ {
                    do {
                        let loginError = try JSONDecoder().decode(ErrorModel.self, from: data!)
                        
                        self.alertMessage = (loginError.errorObj?.errorMsg)!
                        
                        completionHandler(false)
                        
                    } catch let jsonFormatError {
                        
                        self.alertMessage = jsonFormatError.localizedDescription
                        completionHandler(false)
                    }
                }
            }
        }
    }
}

