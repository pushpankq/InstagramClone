//
//  APIManager.swift
//  APIManager Class
//
//  Created by Pushpank Kumar on 21/01/19.
//  Copyright © 2019 Pushpank Kumar. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON


class APIManager {
    
    //singleton Class instance
    static let shared = APIManager()
    
    private init() {
        // Do nothing here...
    }
    
    //   Post Service Methods  
    
    /// getting data from http Method post service
    ///
    /// - Parameters:
    ///   - request: a particular url (API End Point)
    ///   - parameters: send json data to the server
    ///   - completionHandler: callback
    
    func postService(_ urlString: String, andParameter parameters: [String:Any]?, withCompletion completionHandler: @escaping (Data?, Error?)-> () ){
        
        let url = String(format: urlString)
        guard let serviceUrl = URL(string: url) else { return }
        var request = URLRequest(url: serviceUrl)
        
        // Set http method type
        request.httpMethod = "POST"
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters!, options: []) else {
            return
        }
        
        request.httpBody = httpBody
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            
            if let _ = response {
            }
            
            guard error == nil else {
                completionHandler(nil, error)
                return
            }
            
            guard let data = data else {
                print("there was an error with the data")
                return
            }
          
//          let json = try! JSON(data: data)
//
//
//          print(json)
            completionHandler(data, nil)
            
            }.resume()
    }
    
}

