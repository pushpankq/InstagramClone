//
//  UITextView + Extension.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import Foundation
import UIKit

extension UITextField {
    
    // left -- top align
    func topLeftAlignment() {
        self.contentVerticalAlignment = .top
        self.textAlignment = .left
    }
    
    // left -- center align
    func centerLeftAlignment() {
        self.contentVerticalAlignment = .center
        self.textAlignment = .left
    }
    
    // left -- bottom align
    func bottomLeftAlighment () {
        self.contentVerticalAlignment = .bottom
        self.textAlignment = .left
    }
    
    // center -- top align
    func centerTopAlign() {
        self.contentVerticalAlignment = .top
        self.textAlignment = .center
    }
    
    // center -- center align
    func centerVertically() {
        self.contentVerticalAlignment = .center
        self.textAlignment = .center
    }
    
    // center -- bottom align
    func bottomCenterAlighment () {
//        self.contentHorizontalAlignment = .center
        self.contentVerticalAlignment = .bottom
        self.textAlignment = .center
    }
    
    // right -- center align
    func topRightAlignment() {
        self.contentVerticalAlignment = .top
//        self.contentHorizontalAlignment = .right
        self.textAlignment = .right

    }
    
    // right -- center align
    func centerRightAlignment() {
        self.contentVerticalAlignment = .center
        self.textAlignment = .right

//        self.contentHorizontalAlignment = .right
    }
    
    // right -- bottom align
    func bottomRightAlighment () {
        self.contentVerticalAlignment = .bottom
        self.textAlignment = .right
    }
    
}
