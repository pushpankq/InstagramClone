//
//  ScaleSegue.swift
//  MrCanvas
//
//  Created by Mayank Singh on 15/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class ScaleSegue: UIStoryboardSegue {
    
    override func perform()  {
        scale()
    }
    
    func scale()  {
        
        
        
        
        let toVC = self.destination
        let fromVC = self.source
        
        let containerView = fromVC.view.superview
        let originalCenter = fromVC.view.center
        toVC.view.transform = CGAffineTransform(scaleX: 0.05, y: 0.05)
        toVC.view.center = originalCenter
        
//        toVC.modalPresentationStyle = .custom // teehee

        containerView?.addSubview(toVC.view)
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut, animations: {
            toVC.view.transform = CGAffineTransform.identity
        }) { (success) in
                fromVC.present(toVC, animated: false, completion: nil)


        }
    }
}


class FadeInSegue: UIStoryboardSegue {
    
    override func perform()  {
        fadeIn()
    }
    
    func fadeIn()  {
        
        let sourceViewControllerView = self.source.view
        let destinationViewControllerView = self.destination.view
        let screenWidth = UIScreen.main.bounds.size.width
        let screenHeight = UIScreen.main.bounds.size.height
        destinationViewControllerView!.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
        destinationViewControllerView?.alpha = 0
        sourceViewControllerView!.addSubview(destinationViewControllerView!);
        
        UIView.animate(withDuration: 1, animations: {
            destinationViewControllerView!.alpha = 1;
        }, completion: { (finished) in
            destinationViewControllerView!.removeFromSuperview()
            self.source.present(self.destination, animated: false, completion: nil)
        })
    }
}

class UnwindScaleSegue: UIStoryboardSegue {
    
    override func perform()  {
        unwindScale()
    }
    
    func unwindScale()  {
        
        let toVC = self.destination
        let fromVC = self.source
        fromVC.view.superview?.insertSubview(toVC.view, at: 0)
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut, animations: {
            
            fromVC.view.transform = CGAffineTransform(scaleX: 0.05, y: 0.05)

        }) { (success) in
            
            fromVC.dismiss(animated: true, completion: nil)
            print("dismiss")

        }
    }
}


