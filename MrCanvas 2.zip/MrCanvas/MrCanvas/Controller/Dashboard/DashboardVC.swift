//
//  ScaleAnimationViewController.swift
//  Gemini
//
//  Created by shoheiyokoyama on 2017/06/28.
//  Copyright © 2017年 CocoaPods. All rights reserved.
//

import UIKit
import AnimatedCollectionViewLayout
import SideMenu
import RZTransitions
import ARNTransitionAnimator


final class DashboardVC: ImageZoomAnimationVC, ChildCollectionCellClass {
    
//    var parentCollectionViewTitleArray = ["Welcome to MrCanvas ","Unnamed"]
    var shaingDataArray = [["Share","Image"], ["Import", "PDF"], ["Export", "PDF"], ["Export","Docx"] ]
    let dashboardModel = DashboardModel()
    lazy var totalBoards = 0
    lazy var boardsArray = [UserBoardData]()
    var animator : ARNTransitionAnimator?

// IBOutlets
    @IBOutlet weak var sharingTableView: UITableView!
    @IBOutlet weak var addBoardImageView: UIImageView!
    @IBOutlet weak var deleteBoardImageView: UIImageView!
    @IBOutlet weak var sideMenuImageView: UIImageView!
    @IBOutlet weak var sharingView: UIView!
    @IBOutlet weak var shareImageView: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView! {
        didSet {
            collectionView.delegate = self
            collectionView.dataSource = self
        }
    }
    
    
    var selectedIndex = 0
    
    // set cell identifier
    fileprivate let cellIdentifier = "ParentCollectionViewCell"
    // set scrolling direction
    private(set) var scrollDirection: UICollectionView.ScrollDirection = .horizontal

    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupSideMenu()
        self.collectionViewLayoutSetup()
        self.addGesture()
        
        sharingTableView.dataSource = self
        sharingTableView.delegate = self
        sharingTableView.rowHeight = UITableView.automaticDimension
        sharingTableView.estimatedRowHeight = 100
        sharingTableView.tableFooterView = UIView()
        sharingTableView.layer.cornerRadius = 8.0
        
        userboardData()

    }
    
    private func userboardData() {
        
        dashboardModel.getUserboardData(0, boardOperation: BoardOperation.Get.rawValue) {[unowned self] (isSuccess) in
            if isSuccess {
                
                self.totalBoards = self.dashboardModel.totalBoard
                self.boardsArray = self.dashboardModel.boardsArray
                
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    //Call Google maps methods.
                }
            }
        }
    }
    

    
    /// collection View layout Setup
    /// layuot animation is card type
    private func collectionViewLayoutSetup() {
        
        let layout = AnimatedCollectionViewLayout()
        layout.animator = LinearCardAttributesAnimator(minAlpha: 0.5, itemSpacing: 0.1, scaleRate: 0.9)
        layout.itemSize = CGSize(width: view.frame.size.width - 40, height: view.frame.size.height-100)

        layout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = layout
        collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
      //  self.collectionView.decelerationRate = UIScrollViewDecelerationRateFast

        
    }
    
    
    
    /// add all gesture
    private func addGesture() {
        
        // delete board tap gesture
        let deleteBoardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(deleteBoard(tapGestureRecognizer:)))
        deleteBoardImageView.isUserInteractionEnabled = true
        deleteBoardImageView.addGestureRecognizer(deleteBoardTapGestureRecognizer)
        
        // add board tap gesture
        let addBoardTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addBoard(tapGestureRecognizer:)))
        addBoardImageView.isUserInteractionEnabled = true
        addBoardImageView.addGestureRecognizer(addBoardTapGestureRecognizer)
        
        //show sidemenu tap gesture
        let sideMenuTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(sideMenu(tapGestureRecognizer:)))
        sideMenuImageView.isUserInteractionEnabled = true
        sideMenuImageView.addGestureRecognizer(sideMenuTapGestureRecognizer)
        
        // add board tap gesture
        let shareImageTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(shareImage(tapGestureRecognizer:)))
        shareImageView.isUserInteractionEnabled = true
        shareImageView.addGestureRecognizer(shareImageTapGestureRecognizer)
        
        
    }
    
    
    /// side menu setup, drawer width change, blur effect change
    private func setupSideMenu() {
        
        SideMenuManager.default.menuLeftNavigationController = storyboard!.instantiateViewController(withIdentifier: "LeftMenuNavigationController") as? UISideMenuNavigationController
        SideMenuManager.default.menuWidth = UIScreen.main.bounds.width/1.25
        SideMenuManager.default.menuPresentMode = .menuSlideIn
        SideMenuManager.default.menuAnimationFadeStrength = 0.5
        SideMenuManager.default.menuParallaxStrength = 1

    }
    
    
    // side menu setup, drawer width change, blur effect change
    
    @objc func shareImage(tapGestureRecognizer: UITapGestureRecognizer) {
        showSharingView()
    }
    
    @IBAction func closeSharingViewButtonTapped(_ sender: Any) {
        
     self.sharingView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height:  UIScreen.main.bounds.size.height)
        
        //notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        sharingView.layer.shadowColor = UIColor.lightGray.cgColor
        sharingView.layer.shadowOpacity = 1
        sharingView.layer.shadowOffset = CGSize.zero
//        sharingView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 0.3, animations: {
            self.sharingView.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height:  UIScreen.main.bounds.size.height)
        }) { (_) in
            self.sharingView.isHidden = false
            self.sharingView.removeFromSuperview()
        }
        
    }
    
    
    @IBAction func unwindToDashboardVC(segue: UIStoryboardSegue) {
        
        // Do nothing here...
        
       // unwind(for: segue, towards: self)
    }
    
    override func unwind(for unwindSegue: UIStoryboardSegue, towards subsequentVC: UIViewController) {
        let segue = UnwindScaleSegue(identifier: unwindSegue.identifier, source: unwindSegue.source, destination: unwindSegue.destination) {
        }
        
        segue.perform()
        
    }
    
//    override func unwind(for unwindSegue: UIStoryboardSegue, towards subsequentVC: UIViewController) {
//
//        let segue = UnwindScaleSegue(identifier: unwindSegue.identifier, source: unwindSegue.source, destination: unwindSegue.destination) {
//        }
//
//
//    }
    
    
    
    func showSharingView() {
        
        self.view.addSubview(sharingView)
        sharingView.frame = CGRect(x: 0, y: Constants.screenHeight, width: Constants.screenWidth, height:  Constants.screenHeight)
        sharingView.layer.shadowColor = UIColor.lightGray.cgColor
        sharingView.layer.shadowOpacity = 1
        sharingView.layer.shadowOffset = CGSize.zero
        sharingView.layer.shadowRadius = 5
        UIView.animate(withDuration: 0.4) {
            self.sharingView.frame = CGRect(x: 0, y: 0, width: Constants.screenWidth, height:  Constants.screenHeight)
        }
        
        sharingView.isHidden = false
        
    }
    

    
    
    
    
    // delete board gesture defination
    @objc func deleteBoard(tapGestureRecognizer: UITapGestureRecognizer) {
        
        let boardCount = totalBoards
        
        if boardCount != 0 {
            
            let titleString = self.boardsArray[self.selectedIndex].board_name!
            let boardID = self.boardsArray[self.selectedIndex].board_id!
            
            let title =  "Delete \(titleString) ?"
            let alertController = UIAlertController(title: title, message: "This will parmanently delete the Board", preferredStyle: .alert)
            let cancelAlertAction = UIAlertAction(title: "Cancle", style: .default, handler: nil)
            let deleteAlertAction = UIAlertAction(title: "Delete", style: .default) { _ in
                
                self.dashboardModel.getUserboardData(boardID, boardOperation: BoardOperation.Delete.rawValue) { (isSuccess) in
                    
                    if isSuccess {
                        self.totalBoards  = self.dashboardModel.totalBoard
                        
                        DispatchQueue.main.async {
                            
                            self.collectionView.reloadData()
                        }
                        
                        
                        print("success totalBoards",self.totalBoards )
                        
                    }
                }
            }
            
            alertController.addAction(cancelAlertAction)
            alertController.addAction(deleteAlertAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

    
    
    
    
    // add board gesture defination
    @objc func addBoard(tapGestureRecognizer: UITapGestureRecognizer) {
        
        if self.boardsArray.count < 4 {
            
            dashboardModel.getUserboardData(0, boardOperation: BoardOperation.Add.rawValue) { (isSuccess) in
                
                self.totalBoards = self.dashboardModel.totalBoard
                self.boardsArray = self.dashboardModel.boardsArray
                
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            }
        
//        self.parentCollectionViewTitleArray.append("Unnamed")
//        self.collectionView.reloadData()
            
        } else {
            
            let alertController = UIAlertController(title: "MR Canvas", message: "If you want to add more board. Please purchase premium account.", preferredStyle: .alert)
            let notNowAlertAction = UIAlertAction(title: "Not now", style: .default, handler: nil)
            let goPremiumAlertAction = UIAlertAction(title: "Go Premium!", style: .default) { _ in
 
            }
            
            alertController.addAction(notNowAlertAction)
            alertController.addAction(goPremiumAlertAction)
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
    @objc func sideMenu(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "showSideMenu", sender: self)
 
    }
    
    // add board gesture defination
    @objc func showFullScreen(tapGestureRecognizer: UITapGestureRecognizer) {

        print("full screen ")
  
    }
    
    @objc func changeTitle(sender : UIButton){
        
        if let title = sender.titleLabel?.text {
            
            self.changeCellTitle(title: title, index: sender.tag)
        }
    }
    
    func changeSize() {
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SelectedBoard") as! SelectedBoardVC1
        
        let animation = ImageZoomAnimation<ImageZoomAnimationVC>(rootVC: self, modalVC: controller, rootNavigation: self.navigationController)
        
        
        let animator = ARNTransitionAnimator(duration: 0.5, animation: animation)
        controller.transitioningDelegate = animator
        self.animator = animator
        
        self.present(controller, animated: true, completion: nil)
        
        
//
//        DispatchQueue.main.async {
//            self.performSegue(withIdentifier: "showBoard", sender: self)
//
//        }
        
        
    }
    


    
    
    func changeCellTitle(title: String, index: Int) {
        
        let alertController = UIAlertController(title: "", message: "Change Title", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default) { (action) in
            
            let textField = alertController.textFields![0]
            guard let textfieldText = textField.text else {
                
                return
            }
            
            self.boardsArray[self.selectedIndex].board_name = textfieldText
            self.collectionView.reloadData()
            
            let boardId = self.boardsArray[self.selectedIndex].board_id
            
            self.dashboardModel.updateUseboardTitle(boardId!, boardName: textfieldText, completionHandler: { (isSuccess) in
                print("hi")
                
                // do nothing here
            })

        }
        
        alertController.addTextField { (textfield) in
            textfield.text = title
        }
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }

}



// MARK: - UIScrollViewDelegate
extension DashboardVC {

    
    // get collection view index on scrolling
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var visibleRect = CGRect()
        
        visibleRect.origin = collectionView.contentOffset
        visibleRect.size = collectionView.bounds.size
        
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        guard let indexPath = collectionView.indexPathForItem(at: visiblePoint) else { return }
        
        selectedIndex = indexPath.row
        
        DispatchQueue.main.async {
            self.collectionView.reloadData()
            
        }
        print("index is ", selectedIndex)
    }
    
   
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        DispatchQueue.main.async {
            self.collectionView.reloadData()

        }
        
       
    }

}



// MARK: - UICollectionViewDataSource
extension DashboardVC: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return totalBoards
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? ParentCollectionViewCell
        
        cell?.configure(with: boardsArray[indexPath.row].board_name!)
        cell?.buttonTitle.tag = indexPath.row
        cell?.buttonTitle.addTarget(self, action: #selector(changeTitle), for: .touchUpInside)
        cell?.delegate = self
        cell?.setNeedsLayout()
        cell?.layoutIfNeeded()
        
        return cell!

    }
}

// MARK: - UICollectionViewDelegate
extension DashboardVC: UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        UIView.animate(withDuration: 0.8, delay: 0.1, usingSpringWithDamping: 0.9, initialSpringVelocity: 0.9, options: UIView.AnimationOptions.curveEaseInOut, animations: { [unowned self] in
            self.collectionView.reloadItems(at: [indexPath])
            self.collectionView.delegate = self
        }, completion: { success in
            print("success")
        })
    }
}

//
//
//
//
//

//MARK: Tableview Delegate and DataSource

extension DashboardVC: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return shaingDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! DashboardTableViewCell
        cell.functionLabel.text = shaingDataArray[indexPath.row][0]
        cell.mediaTypeLabel.text = shaingDataArray[indexPath.row][1]
        return cell
    }
    
    
}

extension DashboardVC: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            
        }
    }
}



