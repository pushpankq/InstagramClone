//
//  DashboardTableViewCell.swift
//  MrCanvas
//
//  Created by Mayank Singh on 29/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class DashboardTableViewCell: UITableViewCell {

    @IBOutlet weak var functionLabel: UILabel!
    @IBOutlet weak var mediaTypeLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
