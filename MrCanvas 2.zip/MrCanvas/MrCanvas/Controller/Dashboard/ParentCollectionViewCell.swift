//
//  ImageCollectionViewCell.swift
//  Gemini
//
//  Created by shoheiyokoyama on 2017/07/02.
//  Copyright © 2017年 CocoaPods. All rights reserved.
//

import UIKit
//import Gemini

protocol ChildCollectionCellClass: class {
    func changeSize()
}

final class ParentCollectionViewCell: UICollectionViewCell {

    weak var delegate: ChildCollectionCellClass?
    @IBOutlet var buttonTitle: UIButton!
    fileprivate let childCellIdentifier = "childCellIdentifier"
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        layer.cornerRadius = 5
    }

    // configure parent collection view cell
    func configure(with title: String) {
        
        buttonTitle.setTitle(title, for: .normal)

        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 5

        let childCollectionView = UICollectionView(frame: self.bounds, collectionViewLayout: layout)
        addSubview(childCollectionView);
        childCollectionView.backgroundColor = .white
        childCollectionView.clipsToBounds = true
        childCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: childCellIdentifier);
        childCollectionView.delegate = self;
        childCollectionView.dataSource = self;
        
        childCollectionView.translatesAutoresizingMaskIntoConstraints = false
        childCollectionView.leftAnchor.constraint(equalTo: leftAnchor, constant: 0).isActive = true
        childCollectionView.rightAnchor.constraint(equalTo: rightAnchor, constant: 0).isActive = true
        childCollectionView.topAnchor.constraint(equalTo: topAnchor, constant: 48).isActive = true
        childCollectionView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        
         layout.itemSize = CGSize(width: childCollectionView.frame.size.width/5 - 5, height:childCollectionView.frame.size.height/5 - 20)

    }
}

 //MARK: Collection view Delegate and datasources
 //child collection view Delegates
extension ParentCollectionViewCell : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 25
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: childCellIdentifier, for: indexPath)
        cell.backgroundColor = UIColor.init(red: 188/255, green: 243/255, blue: 115/255, alpha: 1)
        return cell;
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.changeSize()
  
    }
    
   

}
