//
//  PresentVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 14/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class PresentVC: UIViewController {

    @IBOutlet weak var getStartedButtonOutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if Helper.getUserDefault(key: Constants.ApiKeys.kUserToken) != nil {
            getStartedButtonOutlet.setTitle("Done", for: .normal)
        } else {
            getStartedButtonOutlet.setTitle("Get Started", for: .normal)
        }
    }

    @IBAction func getStartedButtonTapped(_ sender: UIButton) {
        if sender.titleLabel?.text == "Get Started" {
            self.performSegue(withIdentifier: Constants.Storyboard.Identifier.kGetStartedIdentifier, sender: self)
        } else {
            self.performSegue(withIdentifier: Constants.Storyboard.Identifier.kDoneIdentifier, sender: self)
        }
    }
}
