//
//  GreenViewController.swift
//  MrCanvas
//
//  Created by Mayank Singh on 09/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class CollectionVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
