//
//  ReadBlogVC.swift
//  MrCanvas
//
//  Created by Mayank Singh on 20/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import SideMenu

class ReadBlogVC: UIViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    
    /// side menu setup, drawer width change, blur effect change
   
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
