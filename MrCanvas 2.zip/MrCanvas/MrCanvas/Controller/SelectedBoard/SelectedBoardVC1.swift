//
//  SelectedBoardVC1.swift
//  MrCanvas
//
//  Created by Mayank Singh on 19/03/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit
import Filestack
import FilestackSDK

class SelectedBoardVC1: ImageZoomAnimationVC {
    
    @IBOutlet var animatedView: UIView!
    @IBOutlet var notesAttachmentView: UIView!
    @IBOutlet weak var textEditorImageView: UIImageView!
    @IBOutlet weak var searchImageView: UIImageView!
    @IBOutlet weak var photoPickerImageView: UIImageView!
    
    
    private lazy var backButton = UIButton(type: .custom)
    private var movingCell: MovingCell?
    private lazy var selectedCollectionArray: [String] = (0...24).map { return "\($0)" }
    private lazy var colorArray: [UIColor] = [.white, .red, .white, .green, .blue, .gray, .darkGray, .brown, .cyan, .lightGray, .yellow, .magenta, .orange, .purple, .green, .cyan, .black, .red, .white, .green, .blue, .gray, .darkGray, .brown, .cyan]

    
    /// Creating collection view and adding long press gesture
    private lazy var selectedCollectionView: UICollectionView =  {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: Constants.screenWidth/5 - 2, height: Constants.screenHeight/5 - 2)
        layout.minimumInteritemSpacing = 2
        layout.minimumLineSpacing = 2

        let cv: UICollectionView = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        cv.register(SelectedBoardCollectionViewCell.self, forCellWithReuseIdentifier: SelectedBoardCollectionViewCell.id)
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        cv.showsVerticalScrollIndicator = false
        cv.delegate = self
        cv.addGestureRecognizer(longPressGesture)
        return cv
    }()
    
    
     /// Long Press Gesture
    private lazy var longPressGesture: UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(selectedCollectionView)
        
        
        selectedCollectionView.addSubview(backButton)
        
        
        selectedCollectionView.translatesAutoresizingMaskIntoConstraints = false
        selectedCollectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        selectedCollectionView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        selectedCollectionView.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        selectedCollectionView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true

        
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.leadingAnchor.constraint(equalTo: selectedCollectionView.leadingAnchor, constant: 8.0).isActive = true
        backButton.topAnchor.constraint(equalTo: selectedCollectionView.topAnchor, constant: 8.0).isActive = true
        backButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        backButton.widthAnchor.constraint(equalToConstant: 30).isActive = true
 
        
        if let image = UIImage(named: "HalfSquare.png") {
            backButton.setImage(image, for: .normal)
        }
        
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
        
        animatedView.layer.cornerRadius = 5

        selectedCollectionView.reloadData()
        
        let openTextEditorTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openTextEditor(tapGestureRecognizer:)))
        textEditorImageView.isUserInteractionEnabled = true
        textEditorImageView.addGestureRecognizer(openTextEditorTapGestureRecognizer)
        
        let openSearchEngineTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openSearchEngine(tapGestureRecognizer:)))
        searchImageView.isUserInteractionEnabled = true
        searchImageView.addGestureRecognizer(openSearchEngineTapGestureRecognizer)
        
        let openFilePickerTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(openFilePicker(tapGestureRecognizer:)))
        photoPickerImageView.isUserInteractionEnabled = true
        photoPickerImageView.addGestureRecognizer(openFilePickerTapGestureRecognizer)

    }
    
    @IBAction func makeANoteButtonPressed(_ sender: UIButton) {
        
        showNotesAttachment()
    }
    
    func addBlurEffect()
    {
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.alpha = 0.5
        blurEffectView.frame = self.view.bounds
        
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        self.selectedCollectionView.addSubview(blurEffectView)
    }
    

    @objc func handleLongGesture(gesture: UILongPressGestureRecognizer) {
        
        var cell: (UICollectionViewCell?, IndexPath?) {
            guard let indexPath = selectedCollectionView.indexPathForItem(at: gesture.location(in: selectedCollectionView)),
                let cell = selectedCollectionView.cellForItem(at: indexPath) else { return (nil, nil) }
            return (cell, indexPath)
        }
        
        switch(gesture.state) {
            
        case .began:
            movingCell = MovingCell(cell: cell.0, originalLocation: cell.0?.center, indexPath: cell.1)
            break
        case .changed:
            
            /// Make sure moving cell floats above its siblings.
            movingCell?.cell.layer.zPosition = 100
            movingCell?.cell.center = gesture.location(in: gesture.view!)
            
            break
        case .ended:
            
            swapMovingCellWith(cell: cell.0, at: cell.1)
            movingCell = nil
        default:
            movingCell?.reset()
            movingCell = nil
        }
    }
    
    func swapMovingCellWith(cell: UICollectionViewCell?, at indexPath: IndexPath?) {
        guard let cell = cell, let moving = movingCell else {
            movingCell?.reset()
            return
        }
        
        // update data source
        selectedCollectionArray.swapAt(moving.indexPath.row, indexPath!.row)
        colorArray.swapAt(moving.indexPath.row, indexPath!.row)
        
        // swap cells
        animate(moving: moving.cell, to: cell)
    }
    
    func animate(moving movingCell: UICollectionViewCell, to cell: UICollectionViewCell) {
        longPressGesture.isEnabled = false
        
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.7, options: UIView.AnimationOptions.allowUserInteraction, animations: {
            movingCell.center = cell.center
            cell.center = movingCell.center
        }) { _ in
            self.selectedCollectionView.reloadData()
            self.longPressGesture.isEnabled = true
        }
    }
    
    
    // add board gesture defination
    @objc func openTextEditor(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "ShowTextEditor", sender: self)
     
    }
    
    // add board gesture defination
    @objc func openSearchEngine(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.performSegue(withIdentifier: "ShowSearchEngine", sender: self)
        
    }
    
    func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        
        return true
    }
    
    private func animateIn() {
        
        self.view.addSubview(animatedView)
        animatedView.center = self.selectedCollectionView.center
        animatedView.transform = CGAffineTransform.init(scaleX:1.3, y:1.3)
        animatedView.alpha = 0
        
        UIView.animate(withDuration: 0.4) {
            self.animatedView.alpha = 1
            self.animatedView.transform = CGAffineTransform.identity
        }
        
    }
    
    
    private struct MovingCell {
        let cell: UICollectionViewCell
        let originalLocation: CGPoint
        let indexPath: IndexPath
        
        init?(cell: UICollectionViewCell?, originalLocation: CGPoint?, indexPath: IndexPath?) {
            guard cell != nil, originalLocation != nil, indexPath != nil else { return nil }
            self.cell = cell!
            self.originalLocation = originalLocation!
            self.indexPath = indexPath!
        }
        
        func reset() {
            cell.center = originalLocation
        }
    }


}


//
//
//
//
//

// MARK: UICollectionViewDataSource
extension SelectedBoardVC1 : UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedCollectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: SelectedBoardCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: SelectedBoardCollectionViewCell.id, for: indexPath) as! SelectedBoardCollectionViewCell
        
        cell.backgroundColor = colorArray[indexPath.row]
        cell.titleLable.text = selectedCollectionArray[indexPath.row]
        cell.layer.cornerRadius = 8
        return cell
    }
 
}

//
//
//
//
//

// MARK: UICollectionViewDelegate
extension SelectedBoardVC1: UICollectionViewDelegate {
    
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            
            print("new indexPath ", indexPath.row)
            let cell = collectionView.cellForItem(at: indexPath) as! SelectedBoardCollectionViewCell
            for subview in cell .subviews
            {
                if let item = subview as? UIImageView
                {
                    print("imageview \(item)")
                }
                else if let item = subview as? UITextView {
                    print("UITextView \(item)")
                    
                } else {
                    
                    animateIn()
                }
            }
        }
    
}
//
//
//
//
//

// show Attachment View

extension SelectedBoardVC1 {
    
    /// show make a notes screen
    func showNotesAttachment() {
        
        self.view.addSubview(notesAttachmentView)
        notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1) {
            self.notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }
        
        notesAttachmentView.isHidden = false
        
    }
    
    
    @IBAction func unwindToSelectedBoardVC(segue: UIStoryboardSegue) {
    }
    
    func dismissNotesAttachments()  {
        
        notesAttachmentView.frame = CGRect(x: 10, y: 50, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        
        //notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        notesAttachmentView.layer.shadowColor = UIColor.lightGray.cgColor
        notesAttachmentView.layer.shadowOpacity = 1
        notesAttachmentView.layer.shadowOffset = CGSize.zero
        notesAttachmentView.layer.shadowRadius = 5
        
        UIView.animate(withDuration: 1, animations: {
            self.notesAttachmentView.frame = CGRect(x: 10, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width - 20, height:  UIScreen.main.bounds.size.height - 100)
        }) { (_) in
            self.notesAttachmentView.isHidden = false
            self.notesAttachmentView.removeFromSuperview()
        }
        
        
    }
    
}


//
//
//
//
//

// Access Filestack


extension SelectedBoardVC1 {
    
    // add board gesture defination
    @objc func openFilePicker(tapGestureRecognizer: UITapGestureRecognizer) {
        
        
        
        
        // Initialize a `Policy` with the expiry time and permissions you need.
        let oneDayInSeconds: TimeInterval = 60 * 60 * 24 // expires tomorrow
        let policy = Policy(// Set your expiry time (24 hours in our case)
            expiry: Date(timeIntervalSinceNow: oneDayInSeconds),
            // Set the permissions you want your policy to have
            call: [.pick, .read, .store])
        
        // Initialize a `Security` object by providing a `Policy` object and your app secret.
        // You can find and/or enable your app secret in the Developer Portal.
        guard let security = try? Security(policy: policy, appSecret: "2RNLTY2OEFAJRCMAZEPYYESR5I") else {
            return
        }
        let config = Filestack.Config()
        
        // Make sure to assign an app scheme URL that matches the one configured in your info.plist.
        config.appURLScheme = "filestackdemo"
        
        let client = Filestack.Client(apiKey: "Ap8CMkDyGQyi9pUHcpajiz", security: security, config: config)
        
        config.availableCloudSources = [.facebook, .instagram, .googleDrive, .dropbox, .box, .gitHub, .gmail, .googlePhotos, .oneDrive, .amazonDrive]
        let picker = client.picker()
        
        
        self.present(picker, animated: true)
        
    }
}


final class SelectedBoardCollectionViewCell: UICollectionViewCell {
    static let id: String = "CellId"
    
    lazy var titleLable: UILabel = UILabel(frame: CGRect(x: 0, y: 20, width: self.bounds.width, height: 30))
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLable)
        titleLable.backgroundColor = .green
        backgroundColor = .white
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}
