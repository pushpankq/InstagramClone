//
//  ViewController.swift
//  InstagramClone
//
//  Created by Mayank Singh on 15/05/19.
//  Copyright © 2019 Kumar. All rights reserved.
//

import UIKit

class SignInVC: UIViewController {
  @IBOutlet weak var emailTextField: UITextField!
  
  @IBOutlet weak var passwordTextField: UITextField!
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    emailTextField.customTextfield()
    passwordTextField.customTextfield()
  }


}

